import 'package:cctrack/themes/dark_mode.dart';
import 'package:cctrack/themes/theme_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class UploadCertificatePage extends StatefulWidget {
  @override
  _UploadCertificatePageState createState() => _UploadCertificatePageState();
}

class _UploadCertificatePageState extends State<UploadCertificatePage> {
  String? _selectedCategory;
  String? _selectedSubCategory;
  String? _selectedLevelOrRole;

  // Map of Categories and their corresponding Sub-Categories
  final Map<String, List<String>> subCategories = {
    'Entrepreneurship & Innovation': [
      'Products Developed',
      'Start-up Company (Registered legally)',
      'Patent-Filed',
      'Patent-Published',
      'Patent-Approved',
      'Patent-Licensed',
      'Prototype developed and tested',
      'Awards for Products developed',
      'Innovative Technologies (Developed and used by industries/users)',
      'Got Venture Capital Funding (For innovative ideas/products)',
      'Startup Employment',
      'Societal Innovations',
    ],
    'Leadership & Management': [
      'Core Coordinator',
      'Sub Coordinator',
      'Volunteer',
    ],
    'National Initiatives Participation': [
      'NCC',
      'NSS',
    ],
    'Sports & Games Participation': [
      'Participation',
      'First Prize',
      'Second Prize',
      'Third Prize',
    ],
    'Cultural Activities Participation': [
      'Music',
      'Performing Arts',
      'Literary Arts',
      'Participation',
      'First Prize',
      'Second Prize',
      'Third Prize',
    ],
    'Professional Self Initiatives': [
      'Conference/Seminar Attendance (IITs/NITs)',
      'Paper Presentation/Publication (IITs/NITs)',
      'Poster Presentation/Publication (IITs/NITs)',
      'Industrial Training/Internship (5+ days)',
      'Industrial/Exhibition Visits',
      'Foreign Language Skill (TOEFL/IELTS/BEC)',
      'MOOC with Final Assessment Certificate',
      'Tech Fest',
      'Competitions by Professional Bodies',
       ],
    // 'Professional Self Initiatives 2': [
    //   'Tech Fest',
    //   'Competitions by Professional Bodies',
    // ],
  };

  // Map of Sub-Categories and their corresponding Roles/Levels
  final Map<String, List<String>> rolesLevels = {
    'Participation': ['Level I', 'Level II', 'Level III', 'Level IV', 'Level V'],
    'First Prize': ['Level I', 'Level II', 'Level III', 'Level IV', 'Level V'],
    'Second Prize': ['Level I', 'Level II', 'Level III', 'Level IV', 'Level V'],
    'Third Prize': ['Level I', 'Level II', 'Level III', 'Level IV', 'Level V'],
    'Music': ['Level I', 'Level II', 'Level III', 'Level IV', 'Level V'],
    'Performing Arts': ['Level I', 'Level II', 'Level III', 'Level IV', 'Level V'],
    'Literary Arts': ['Level I', 'Level II', 'Level III', 'Level IV', 'Level V'],
    'Tech Fest': ['Level I', 'Level II', 'Level III', 'Level IV', 'Level V'],
    'Competitions by Professional Bodies': ['Level I', 'Level II', 'Level III', 'Level IV', 'Level V'],
  };

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context); // Access current theme

    return Scaffold(
      appBar: AppBar(
        title: const Text(''),
        titleTextStyle: const TextStyle( // Use TextStyle here
        fontWeight: FontWeight.bold,
        fontSize: 20,
         ),
        backgroundColor: theme.colorScheme.surface,
        foregroundColor: theme.colorScheme.tertiary,
        actions: [
          IconButton(
            icon: Icon(
              theme.colorScheme.brightness == Brightness.light
                  ? Icons.dark_mode
                  : Icons.light_mode,
            ),
            onPressed: () {
              Provider.of<ThemeProvider>(context, listen: false).toggleTheme(darkMode);
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Upload Certificate',
                    style:  TextStyle( // Use TextStyle here
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
         ),
            ),
            Text(
              "Enter the category details",
                style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: theme.colorScheme.inversePrimary,
              ),
            ),
            const SizedBox(height: 16),

            _buildTextField(label: "Event name", hintText: "Name", theme: theme),
            const SizedBox(height: 16),
            _buildDropdownField1(label: "Category",hintText:"categories", theme: theme),
            const SizedBox(height: 16),
            if (_selectedCategory != null)
              _buildDropdownField2(label: "Sub-Category",hintText:"sub-categories", theme: theme),
            const SizedBox(height: 16),
            if (_selectedSubCategory != null)
              _buildDropdownField3(label: "Level or Role", theme: theme),
            const SizedBox(height: 16),
            _buildTextField(label: "Certificate link", hintText: "Drive link", theme: theme),
            const SizedBox(height: 16),
            _buildTextField(label: "Duration or Specific date", hintText:"eg.2 years" ,theme:theme),
            const Spacer(),
             Align(
              alignment: Alignment.centerLeft, // Aligns the button to the left
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: theme.colorScheme.secondary,
                  foregroundColor: theme.colorScheme.surface,
                  minimumSize: const Size(150, 70), // Set width and height (150px width, 70px height)
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0), // Small border radius for a rectangular button
                  ),
                ),
                onPressed: () {
                  // Handle submission action
                },
                child: const Text("Submit"),
              ),
            ),


          ],
        ),
      ),
    );
  }

 Widget _buildTextField({
  required String label,
  String? hintText,
  required ThemeData theme,
}) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        label,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: theme.colorScheme.tertiary,
        ),
      ),
      const SizedBox(height: 16),
      TextField(
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.bold,
            color: Colors.grey,
          ),
          filled: true,
          fillColor: theme.colorScheme.surface,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
            borderSide: BorderSide(
              color: theme.colorScheme.primary, // Updated border color
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(
              color: theme.colorScheme.primary, // Updated enabled border color
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15.0),
            borderSide: BorderSide(
              color: theme.colorScheme.primary, // Updated focused border color
              width: 2.0, // Optional: thicker border when focused
            ),
          ),
        ),
      ),
    ],
  );
}


  // Category dropdown
  Widget _buildDropdownField1({required String label,required String hintText, required ThemeData theme}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: theme.colorScheme.tertiary,
          ),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _selectedCategory,
          items: subCategories.keys
              .map((String value) => DropdownMenuItem<String>(
                    value: value,
                    child: Text(
                      value,
                      style: TextStyle(
                        fontSize: 14,
                        color: theme.colorScheme.tertiary,
                      ),
                    ),
                  ))
              .toList(),
          onChanged: (value) {
            setState(() {
              _selectedCategory = value;
              _selectedSubCategory = null; // Reset subcategory when category changes
              _selectedLevelOrRole = null; // Reset level/role when category changes
            });
          },
          decoration: InputDecoration(
            filled: true,
            fillColor: theme.colorScheme.surface,
             border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
            borderSide: BorderSide(
              color: theme.colorScheme.primary, // Updated border color
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(
              color: theme.colorScheme.primary, // Updated enabled border color
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15.0),
            borderSide: BorderSide(
              color: theme.colorScheme.primary, // Updated focused border color
              width: 2.0, // Optional: thicker border when focused
            ),
          ),
        ),
        ),
      ],
    );
  }

  // Sub-category dropdown
  Widget _buildDropdownField2({required String label, required ThemeData theme, required String hintText}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: theme.colorScheme.tertiary,
          ),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _selectedSubCategory,
          items: subCategories[_selectedCategory!]!
              .map((String value) => DropdownMenuItem<String>(
                    value: value,
                    child: Text(
                      value,
                      style: TextStyle(
                        fontSize: 14,
                        color: theme.colorScheme.tertiary,
                      ),
                    ),
                  ))
              .toList(),
          onChanged: (value) {
            setState(() {
              _selectedSubCategory = value;
              _selectedLevelOrRole = null; // Reset level/role when subcategory changes
            });
          },
          decoration: InputDecoration(
            filled: true,
            fillColor: theme.colorScheme.surface,
             border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
            borderSide: BorderSide(
              color: theme.colorScheme.primary, // Updated border color
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(
              color: theme.colorScheme.primary, // Updated enabled border color
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15.0),
            borderSide: BorderSide(
              color: theme.colorScheme.primary, // Updated focused border color
              width: 2.0, // Optional: thicker border when focused
            ),
          ),
        ),
        ),
      ],
    );
  }


  // Level or Role dropdown
  Widget _buildDropdownField3({required String label, required ThemeData theme}) {
    if (_selectedSubCategory == null ||
        !rolesLevels.containsKey(_selectedSubCategory!)) return SizedBox();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: theme.colorScheme.tertiary,
          ),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _selectedLevelOrRole,
          items: rolesLevels[_selectedSubCategory!]!
              .map((String value) => DropdownMenuItem<String>(
                    value: value,
                    child: Text(
                      value,
                      style: TextStyle(
                        fontSize: 14,
                        color: theme.colorScheme.tertiary,
                      ),
                    ),
                  ))
              .toList(),
          onChanged: (value) {
            setState(() {
              _selectedLevelOrRole = value;
            });
          },
            decoration: InputDecoration(
            filled: true,
            fillColor: theme.colorScheme.surface,
            border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
            borderSide: BorderSide(
              color: theme.colorScheme.primary, // Updated border color
            ),
          ),
            enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
            borderSide: BorderSide(
              color: theme.colorScheme.primary, // Updated enabled border color
            ),
          ),
            focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15.0),
            borderSide: BorderSide(
              color: theme.colorScheme.primary, // Updated focused border color
              width: 2.0, // Optional: thicker border when focused
            ),
          ),
        ),
        ),
      ],
    );
  }
}